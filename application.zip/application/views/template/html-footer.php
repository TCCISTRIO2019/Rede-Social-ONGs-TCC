    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <!-- jQuery -->
    <script src="<?php echo base_url('assets/public/js/jquery.js') ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url('assets/public/js/bootstrap.min.js') ?>"></script>

    <!-- JavaScript tela de mensagens -->
    <script src="<?php echo base_url('assets/public/js/script_mensagens.js') ?>"></script>

    <script type='text/javascript'>
        var baseURL= "<?php echo base_url();?>";
    </script>

<!--    <script>-->
<!--        var er = new RegExp('([0-9]{5}-[0-9]{3})');-->
<!---->
<!--        if(er.test(cep.value))-->
<!--        {-->
<!--            // return true;-->
<!--        }else{-->
<!--            var unsetPHPError = document.querySelector("#errMessage");-->
<!--            if(unsetPHPError.innerHTML != ""){ unsetPHPError.innerHTML = ""; }-->
<!---->
<!--            message.textContent = "E-mail digitado não está escrito corretamente! formato: ex@anything.a (.b)";-->
<!--            // return false;-->
<!--        }-->
<!--    </script>-->

</body>

</html>