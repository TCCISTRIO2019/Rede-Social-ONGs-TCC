<header class="fixed-top">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="">TCC Rede Social</a>
                    </li>

                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo base_url('home') ?>">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>